package com.reto3.ciclo3.CrudRepository;

import com.reto3.ciclo3.Entidad.Category;

import org.springframework.data.repository.CrudRepository;

public interface CategoryCrudRepository extends CrudRepository <Category, Integer> {
}
