package com.reto3.ciclo3.CrudRepository;

import com.reto3.ciclo3.Entidad.Client;

import org.springframework.data.repository.CrudRepository;

public interface ClientCrudRepository extends CrudRepository <Client, Integer> {

}